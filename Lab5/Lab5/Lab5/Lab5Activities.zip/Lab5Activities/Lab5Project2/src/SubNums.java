import java.util.Scanner;
public class SubNums {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Upto which number you need the subtraction of numbers? ");
        int n = sc.nextInt();
        System.out.println("");
        
        System.out.println("The subtraction of numbers from 1 to "+n+" is "+SubNumbers(n));
    }
    
    public static int SubNumbers(int a){
        
        
        
        
        
        
        return 0; //Remove this statement after writing your code
    }
}
