import java.util.Scanner;
public class CountArecursive {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter any string: ");
        String str = sc.next();
        System.out.println();
        int numAs = countA(str);
        System.out.println("Number of A's in the string "+str+" is "+numAs);
    }
    
    
    public static int countA(String str) {
        
        
        
        
        

        return 0;  //Remove this statement after writing your code

    }

}
