import java.util.Scanner;
public class PairStarsRecursive {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter any string: ");
        String str = sc.next();
        System.out.println();
        String newstr = pairStar(str);
        System.out.println("Old string was "+str);
        System.out.println("New string after inserting *s in adjacent identical characters is "+newstr);
    }
     
    public static String pairStar(String str){
        
        
        
        
        
        
        
		return ""; //Remove this statement after writing your code
	}

}
