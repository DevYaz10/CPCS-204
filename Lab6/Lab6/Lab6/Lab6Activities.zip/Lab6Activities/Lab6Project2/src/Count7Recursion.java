import java.util.Scanner;
public class Count7Recursion {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter any number: ");
        int d = sc.nextInt();
        System.out.println();
        int num7s = count7(d);
        System.out.println("Number of 7's in the number "+d+" is "+num7s);
    }
    
    
    public static int count7(int n) {
        
        
        
        
        
        
        return 0; //Remove this statement after writing your code
    }

}